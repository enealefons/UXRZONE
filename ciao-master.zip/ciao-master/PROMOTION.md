## Scene Promotion

As part of publishing your scene, you can choose to allow Mozilla to promote your scene. If you choose to allow Mozilla to promote your scene, you grant to Mozilla a non-exclusive, worldwide, royalty-free, sublicensable license under all of Your rights necessary to review your scene, and publish, distribute, and promote it as part of Hubs and Spoke or related Mozilla promotional efforts.
