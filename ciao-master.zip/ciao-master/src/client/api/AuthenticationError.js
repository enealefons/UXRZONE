export default class AuthenticationError extends Error {}
