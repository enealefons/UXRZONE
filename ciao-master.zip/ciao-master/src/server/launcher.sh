#!/bin/bash
script_dir=$(dirname "$0")
"$script_dir/runtime.bin"
